/* UIHud.js --------------------------------------------------------------- */
import { UIBase } from './UIBase.js';

/**
 * 画面左上にコイン枚数を表示する HUD
 */
export class UIHud extends UIBase {
        /**
         * @param {HTMLElement} parentElement – 通常は #game-ui-layer
         * @param {PlayerBase=} wizard        – コインを持つプレイヤー
         */
        constructor(parentElement, wizard = null) {
                super(parentElement);
                this.wizard = wizard;

                /* ────── 見た目 ────── */
                this.element.classList.add('hud-element');
                this.element.style.position   = 'absolute';
                this.element.style.left       = '12px';
                this.element.style.top        = '12px';
                this.element.style.color      = '#f6c915';     // コインと同系色
                this.element.style.fontSize   = '24px';
                this.element.style.fontWeight = 'bold';
                this.element.style.textShadow = '0 0 6px rgba(0,0,0,.6)';

                /* 🪙 アイコン＋数字 */
                this.iconSpan  = document.createElement('span');
                this.iconSpan.textContent = '🪙';
                this.iconSpan.style.marginRight = '4px';

                this.textSpan  = document.createElement('span');

                this.element.append(this.iconSpan, this.textSpan);

                /* 初期表示 */
                this.updateDisplay();
        }

        /** プレイヤーを後から差し替えたい場合用 */
        setWizard(wizard) {
                this.wizard = wizard;
                this.updateDisplay();
        }

        /** コイン枚数を再描画 */
        updateDisplay() {
                if (!this.wizard) {
                        this.textSpan.textContent = '—';
                        return;
                }
                this.textSpan.textContent = String(this.wizard.playerstatus.coins ?? 0);
        }
}
