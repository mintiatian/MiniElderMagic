﻿// Script/BackgroundCanvas.js
import { TILE_SIZE } from './GameData.js';
import { MapDataTable } from './Utils/DataTable.js';

export class Background {
    /**
     * @param {HTMLElement} parentEl   #game-area
     * @param {Camera}      camera
     */
    constructor(parentEl, camera) {
        this.camera = camera;
        this.tile   = TILE_SIZE;
        this.map    = MapDataTable.getMap();

        this.rows   = this.map.length;
        this.cols   = this.map[0].length;

        /* ===== ① オフスクリーン: ワールド全域を描く ===== */
        const worldW = this.cols * this.tile;
        const worldH = this.rows * this.tile;

        this.worldCanvas        = document.createElement('canvas');
        this.worldCanvas.width  = worldW;
        this.worldCanvas.height = worldH;
        const wctx = this.worldCanvas.getContext('2d');

        wctx.font = `${this.tile * 0.9}px serif`;
        wctx.textAlign = 'center';
        wctx.textBaseline = 'middle';

        for (let r = 0; r < this.rows; ++r) {
            for (let c = 0; c < this.cols; ++c) {
                const char = this.map[r][c];
                if (!char) continue;                   // 空地スキップ
                const x = c * this.tile + this.tile * 0.5;
                const y = r * this.tile + this.tile * 0.5;
                wctx.fillText(char, x, y);
            }
        }

        /* ===== ② 表示キャンバス: 画面サイズ分だけ ===== */
        this.viewCanvas        = document.createElement('canvas');
        this.viewCanvas.width  = camera.vw;   // baseWidth
        this.viewCanvas.height = camera.vh;   // baseHeight
        this.ctx = this.viewCanvas.getContext('2d');

        //parentEl.appendChild(this.viewCanvas);

        const viewport = parentEl.parentElement;   // index.html 側で <div id="viewport"> にしておく
        Object.assign(this.viewCanvas.style, {
            position: 'absolute', left: '0', top:  '0', pointerEvents: 'none',   // クリック透過
            zIndex: 0                // 背景奥へ
        });
        viewport.appendChild(this.viewCanvas);
    }

    isSolidAt(x, y) {               // ← ワールド座標(px)
        const c = Math.floor(x / TILE_SIZE);
        const r = Math.floor(y / TILE_SIZE);
        if (r < 0 || c < 0 || r >= this.rows || c >= this.cols) return true; // 外は壁扱い
        return !!this.map[r][c];       // そこに岩や水がある？
    }

    /** 毎フレーム呼ぶ */
    update() {
        const view = this.camera.getViewRect();
        this.ctx.clearRect(0, 0, this.viewCanvas.width, this.viewCanvas.height);

        this.ctx.drawImage(
            this.worldCanvas,
            view.left, view.top,               // sx, sy
            view.width, view.height,           // sw, sh
            0, 0,                              // dx, dy
            view.width, view.height            // dw, dh
        );
    }
}
